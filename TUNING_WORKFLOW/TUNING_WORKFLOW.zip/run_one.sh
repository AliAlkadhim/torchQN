#!/bin/bash

#DAVIDSON
# export DATA_DIR='/home/DAVIDSON/alalkadhim.visitor/IQN/DAVIDSON_NEW/data'
#LOCAL
export DATA_DIR='/home/ali/Desktop/Pulled_Github_Repositories/IQN_HEP/Davidson/data'

python Optuna_Train_Evaluate_pT.py 
#python Optuna_Train_Evaluate_Eta.py 
#python Optuna_Train_Evaluate_phi.py 
#python Optuna_Train_Evaluate_m.py 



######################EXPERIMENTAL
# python OptunaTunepT.py