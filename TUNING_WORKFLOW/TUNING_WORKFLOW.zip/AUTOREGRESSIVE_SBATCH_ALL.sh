#!/bin/bash
# echo "shell" $0                                                                                                                                                                                         $
# rnd=$(($1 + 1)) 
# CHANGE JOB NAME
#SBATCH --job-name "2Tuned_AUTOREG"
#SBATCH --output "log_AUTOREGRESSIVE/output_sbatch_Autoregressive_.%j.log"
#SBATCH --ntasks 4
#SBATCH --cpus-per-task 32
#SBATCH --mem-per-cpu 30g
#SBATCH --time-min=90:90
#SBATCH --oversubscribe



#DAVIDSON
export DATA_DIR='/home/DAVIDSON/alalkadhim.visitor/IQN/DAVIDSON_NEW/data'
#LOCAL
#export DATA_DIR='/home/ali/Desktop/Pulled_Github_Repositories/IQN_HEP/Davidson/data'

python Optuna_Train_Evaluate_pT.py 
python Optuna_Train_Evaluate_Eta.py 
python Optuna_Train_Evaluate_phi.py 
python Optuna_Train_Evaluate_m.py 


### DO scontrol -d show job <jobid> for more details
